#!/bin/bash
# Deploy Scaffold-ETH Integration Work to Remote Server
# Runs multiple agent swarms in parallel on remote server for faster development

set -e

# Load environment variables from .env
if [ -f .env ]; then
    export $(grep -v '^#' .env | xargs)
fi

# Check required environment variables
if [ -z "$REMOTE_HOST" ] || [ -z "$REMOTE_PORT" ] || [ -z "$REMOTE_USER" ]; then
    echo "ERROR: Missing required environment variables"
    echo "Please configure REMOTE_HOST, REMOTE_PORT, and REMOTE_USER in your .env file"
    exit 1
fi

# Colors
GREEN='\033[0;32m'
BLUE='\033[0;34m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

echo -e "${BLUE}🔗 Deploying Scaffold-ETH Integration to Remote Server${NC}\n"

# Check if remote server is reachable
echo -e "${YELLOW}📡 Checking remote server connection...${NC}"
if ! ssh -o ConnectTimeout=5 -p ${REMOTE_PORT} ${REMOTE_USER}@${REMOTE_HOST} "echo 'Connected'" 2>/dev/null; then
    echo -e "${YELLOW}⚠️  Cannot reach remote server. Will work locally.${NC}"
    LOCAL_MODE=true
else
    echo -e "${GREEN}✅ Remote server is reachable${NC}\n"

    # Check server resources
    echo -e "${BLUE}📊 Checking server resources...${NC}"
    ssh -p ${REMOTE_PORT} ${REMOTE_USER}@${REMOTE_HOST} "free -h | grep Mem && echo 'CPU cores:' && nproc"
    echo ""

    LOCAL_MODE=false
fi

# Create remote directory
if [ "$LOCAL_MODE" = false ]; then
    echo -e "${BLUE}📁 Setting up remote workspace...${NC}"
    ssh -p ${REMOTE_PORT} ${REMOTE_USER}@${REMOTE_HOST} "mkdir -p ~/spec-kit-assistant-work/scaffold-eth-integration"

    # Sync files to remote server
    echo -e "${BLUE}📤 Syncing files to remote server...${NC}"
    rsync -avz -e "ssh -p ${REMOTE_PORT}" \
        --exclude 'node_modules' \
        --exclude '.git' \
        --exclude '*.log' \
        ./ ${REMOTE_USER}@${REMOTE_HOST}:~/spec-kit-assistant-work/scaffold-eth-integration/

    echo -e "${GREEN}✅ Files synced to remote server${NC}\n"
fi

# Define swarm tasks
declare -a TASKS=(
    "Generate comprehensive ERC-721 NFT contract with royalties"
    "Create staking contract with reward distribution"
    "Build NFT marketplace with listing and bidding"
    "Generate DAO governance contracts"
)

# Run swarms
echo -e "${BLUE}🤖 Deploying ${#TASKS[@]} parallel swarms...${NC}\n"

if [ "$LOCAL_MODE" = false ]; then
    # Run on remote server in background
    for i in "${!TASKS[@]}"; do
        TASK="${TASKS[$i]}"
        echo -e "${YELLOW}   Swarm $((i+1)): ${TASK}${NC}"

        ssh -p ${REMOTE_PORT} ${REMOTE_USER}@${REMOTE_HOST} \
            "cd ~/spec-kit-assistant-work/scaffold-eth-integration && nohup node deploy-web3-scaffold-eth-swarm.js '${TASK}' > logs/swarm-$i.log 2>&1 &"
    done

    echo -e "${GREEN}\n✅ All swarms deployed to remote server!${NC}"
    echo -e "${BLUE}📊 Monitor progress: ssh -p ${REMOTE_PORT} ${REMOTE_USER}@${REMOTE_HOST} 'tail -f ~/spec-kit-assistant-work/scaffold-eth-integration/logs/*.log'${NC}\n"
else
    # Run locally
    mkdir -p logs
    for i in "${!TASKS[@]}"; do
        TASK="${TASKS[$i]}"
        echo -e "${YELLOW}   Swarm $((i+1)): ${TASK}${NC}"
        node deploy-web3-scaffold-eth-swarm.js "${TASK}" > "logs/swarm-$i.log" 2>&1 &
    done

    echo -e "${GREEN}\n✅ All swarms running locally!${NC}"
    echo -e "${BLUE}📊 Monitor: tail -f logs/*.log${NC}\n"
fi

# Wait for completion
echo -e "${BLUE}⏳ Swarms are running in background...${NC}"
echo -e "${YELLOW}💡 Tip: This will take 5-10 minutes. Check logs for progress.${NC}\n"

# Provide monitoring commands
echo -e "${BLUE}📖 Useful commands:${NC}"
if [ "$LOCAL_MODE" = false ]; then
    echo -e "   ${NC}Check server resources: ssh -p ${REMOTE_PORT} ${REMOTE_USER}@${REMOTE_HOST} 'htop'${NC}"
    echo -e "   ${NC}View logs: ssh -p ${REMOTE_PORT} ${REMOTE_USER}@${REMOTE_HOST} 'cat ~/spec-kit-assistant-work/scaffold-eth-integration/logs/swarm-0.log'${NC}"
    echo -e "   ${NC}Sync results back: rsync -avz -e 'ssh -p ${REMOTE_PORT}' ${REMOTE_USER}@${REMOTE_HOST}:~/spec-kit-assistant-work/scaffold-eth-integration/ ./remote-results/${NC}"
    echo -e "   ${NC}Server status: ssh -p ${REMOTE_PORT} ${REMOTE_USER}@${REMOTE_HOST} 'ps aux | grep node'${NC}"
else
    echo -e "   ${NC}View logs: tail -f logs/*.log${NC}"
    echo -e "   ${NC}Check processes: ps aux | grep 'deploy-web3'${NC}"
fi

echo -e "\n${GREEN}🐕 Spec says: Swarms deployed to remote server! They'll work in parallel while you focus on the grant! 🚀${NC}\n"
